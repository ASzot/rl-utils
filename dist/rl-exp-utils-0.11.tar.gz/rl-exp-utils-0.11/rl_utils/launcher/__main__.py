from rl_utils.launcher.run_exp import full_execute_command_file

full_execute_command_file()
